export const CMS_NAME = "LObserver";
export const CMS_SEPARATOR = "-";
export const BASE_URL = "https://lobserver.com";
